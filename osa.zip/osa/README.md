# Osa

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pol-Bru-Gil/pen/MWxgXPP](https://codepen.io/Pol-Bru-Gil/pen/MWxgXPP).

